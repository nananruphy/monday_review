package com.example.akosombotour;

import java.util.ArrayList;

public class ToursitesModel {
    //declare private data instead of public to ensure the privacy of data field of each class
    private String history;
    public ToursitesModel(String history) {
        this.history = history;
    }
    //retrieve user's name
    public String getHistory(){
        return history;
    }
    public static ArrayList<ToursitesModel> getUsers() {
        ArrayList<ToursitesModel> history = new ArrayList<ToursitesModel>();
        history.add(new ToursitesModel("Akosombo Dam"));
        history.add(new ToursitesModel("Adomi Bridge"));
        history.add(new ToursitesModel("Akosombo Tixtles)"));
        history.add(new ToursitesModel("Akosombo International School"));
        return history;
    }
}


