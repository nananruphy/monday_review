package com.example.akosombotour;

import java.util.ArrayList;

public class HistoryModel {
    private String history;
    public HistoryModel(String history) {
        this.history = history;
    }
    public String getHistory(){
        return history;
    }
    public static ArrayList<HistoryModel> getUsers() {
        ArrayList<HistoryModel> history = new ArrayList<HistoryModel>();
        history.add(new HistoryModel("History of Akosombo Town"));
        history.add(new HistoryModel("Location and Size"));
        history.add(new HistoryModel("Chiefs"));
        history.add(new HistoryModel("Climate"));
        history.add(new HistoryModel("Population Composition"));
        return history;
    }
}